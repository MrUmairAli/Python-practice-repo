import streamlit as st
import time
from time import sleep
import mysql.connector
d=mysql.connector.connect(host="localhost",user="root",passwd="1234",database="log_history")
c=d.cursor()
def signin(n,p):
    c.execute("insert into records values(%s,%s)",(n,p))
    d.commit()
    print ("ADDED SUCESSFULLY")
def login(n,p):
    c.execute("SELECT * FROM records WHERE username=%s AND password=%s", (n, p))
    if c.fetchone():
        return True
    else:
      return  False

def main():
  
  st.set_page_config(
    page_title="My App",
    page_icon="🔒",
    layout="centered",
    initial_sidebar_state="collapsed"  # This hides the sidebar by defaul)
     
)
  st.markdown("""
    <style>
        [data-testid="stSidebar"] {
            display: none;
        }
        [data-testid="collapsedControl"] {
            display: none;
        }
    </style>
""", unsafe_allow_html=True)
  if "page" not in st.session_state:
   st.session_state="sigin"

  st.title ("Welcome to the sigin Page")
  inputs()
  buttons()
  
def inputs():
  col1,col2,col3=st.columns([1,6,1])
  with col1:
    x=str(st.text_input("ENTER YOUR USERNAME",placeholder="username"))
  with col2:
    y=str(st.text_input("ENTER YOUR password",placeholder="password"))
  with col3:
    z=str(st.text_input("ENTER YOUR EMAIL",placeholder="EMAIL"))
  submitted=st.button("SUBMIT")
  
  if submitted:
    if not x or not y or not z:
      st.warning("enter all the contents")
      return 0
    if not x.isalnum() or len(x)<5  :
      st.error("invalid username try alphanumeric")
      return 0
    if not y.isalnum() or len(y) < 8  : 
      st.error(" Pass lenght less than 8 or not alphanumeric")
      return 0
    if "@gmail.com" not in z:
      st.error("invalid gmail")
      return 0
    
    st.success("sucessfull submitted")
    signin(x,y)
    sleep(2)
    st.session_state="main_page"
    if st.session_state=="main_page":
       st.switch_page("app.py")

def buttons():

  if st.button("GO BACK"):
    st.session_state="main_page"
  if st.button("login"):
    st.session_state="log_in"
  if st.session_state=="log_in":
   st.switch_page("pages/login.py")
  if st.session_state=="main_page":
   st.switch_page("app.py")
if __name__=="__main__":
  main()