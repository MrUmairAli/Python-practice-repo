import streamlit as st

def main():
    st.set_page_config(
    page_title="My App",
    page_icon="🔒",
    layout="centered",
    initial_sidebar_state="collapsed"  # This hides the sidebar by default
)  
    st.markdown("""
    <style>
        [data-testid="stSidebar"] {
            display: none;
        }
        [data-testid="collapsedControl"] {
            display: none;
        }
    </style>
""", unsafe_allow_html=True) 
    if "page" not in st.session_state:
       st.session_state="mainpage"
    st.title("welcome to My App")
    buttons()
def buttons():
    col1,col2,col3=st.columns([1,1,1])
    with col1:
     if st.button("LOGIN"):
        st.session_state="login_page"
    with col2 :
     st.write("  OR") 
    with col3:
     if st.button("SIGN UP")  :
        st.session_state="sign_page"  
     
    if st.session_state== "login_page":
        st.switch_page("pages/login.py")      
    if st.session_state == "sign_page":
        st.switch_page("pages/sigin.py")
    
if __name__ == "__main__":
    main()