import streamlit as st
from time import sleep
import mysql.connector
d=mysql.connector.connect(host="localhost",user="root",passwd="1234",database="log_history")
c=d.cursor()
def signin(n,p):
    c.execute("insert into records values(%s,%s)",(n,p))
    d.commit()
    print ("ADDED SUCESSFULLY")
def login(n,p):
    c.execute("SELECT * FROM records WHERE username=%s AND password=%s", (n, p))
    if c.fetchone():
        return  True
    else:
      
      return False
      
def apply_css():
    """Apply custom CSS styles"""
    st.markdown("""
    <style>
        /* Hide sidebar */
        [data-testid="stSidebar"] {
            display: none;
        }
        [data-testid="collapsedControl"] {
            display: none;
        }
        
        /* Box container */
        .box-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border: 2px solid #f0f0f0;
            margin: 2rem auto;
            max-width: 450px;
        }
        
        /* Center the title */
        h1 {
            text-align: center;
            color: #1f1f1f;
        }
        
        /* Style inputs */
        .stTextInput>div>div>input {
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        
        /* Style buttons */
        .stButton>button {
            border-radius: 8px;
            border: none;
            background-color: #4CAF50;
            color: white;
            padding: 0.5rem 1rem;
        }
        
        .stButton>button:hover {
            background-color: #45a049;
        }
    </style>
    """, unsafe_allow_html=True)
def main():
  st.set_page_config(
    page_title="My App",
    page_icon="🔒",
    layout="centered",
    initial_sidebar_state="collapsed"  # This hides the sidebar by default
  )
  st.markdown("""
    <style>
        [data-testid="stSidebar"] {
            display: none;
        }
        [data-testid="collapsedControl"] {
            display: none;
        }
    </style>
""", unsafe_allow_html=True)
  if "page" not in st.session_state:
   st.session_state="login_page"
  inputs()
  buttons()
def inputs():
  st.title ("Welcome to the login Page") 
  col1 ,col2 = st.columns(2)
  with col1:
    username=st.text_input("ENTER YOUR USERNAME",placeholder="username")
  with col2:
    password=st.text_input("ENTER YOUR password",placeholder="password",type="password")
  submitted=st.button("SUBMIT")
  if submitted:
    if login(username,password):
      st.success("login sucessfully")
      st.session_state="app_page"
      if st.session_state=="app_page":
       sleep(2)
       st.switch_page("pages/course_pridictor.py")
    else:
      st.error("invalid username or password")
def buttons():
  if st.button("GO BACK"):
    st.session_state="main_page"
  if st.button("SIGN UP"):
    st.session_state="sigin_page"
  if st.session_state=="sigin_page":
    st.switch_page("pages/sigin.py")
  if st.session_state=="main_page":
   st.switch_page("app.py")

if __name__=="__main__":    
  main()

   