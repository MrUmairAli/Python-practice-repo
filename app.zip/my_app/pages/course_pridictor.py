import os
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import streamlit as st
import matplotlib.pyplot as plt

# CSV FILE LOCATION
CSV_PATH = r"E:\Web\my_app\pages\Course_Completion_Prediction.csv"
MODEL_FILE = "simple_model.pkl"

# ----------------------------------------------------
# TRAIN MODEL (ONLY IF MODEL DOES NOT EXIST)
# ----------------------------------------------------
def train_model():
    print("Loading data...")
    df = pd.read_csv(CSV_PATH)

    # Features
    X = df[['Progress_Percentage', 'Quiz_Score_Avg']]
    y = df['Completed'].map({'Completed': 1, 'Not Completed': 0})

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model
    print("Training simple model...")
    model = LogisticRegression()
    model.fit(X_train, y_train)

    # Accuracy
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"✅ Model accuracy: {accuracy:.2%}")

    # Save
    with open(MODEL_FILE, 'wb') as f:
        pickle.dump(model, f)

    print("💾 Model saved as simple_model.pkl")
    return model

# ----------------------------------------------------
# LOAD MODEL
# ----------------------------------------------------
def load_model():
    if os.path.exists(MODEL_FILE):
        with open(MODEL_FILE, 'rb') as f:
            return pickle.load(f)
    else:
        return train_model()

# ----------------------------------------------------
# STREAMLIT APP
# ----------------------------------------------------
st.set_page_config(page_title="Simple Course Predictor", layout="centered")

st.title("Simple Course Completion Predictor")
st.write("*Single File - Auto Trains If Needed*")

# Load model
model = load_model()

# -------------------------
# Main page inputs (no sidebar)
# -------------------------
st.header("Student Details")


progress = st.slider("Progress Percentage", 0, 100, 60)
quiz_score = st.slider("Quiz Average Score", 0, 100, 70)

# Predict button
if st.button("🎯 Predict", type="primary"):
    input_data = [[progress, quiz_score]]
    prediction = model.predict(input_data)[0]
    probability = model.predict_proba(input_data)[0]

    col1, col2 = st.columns(2)
    with col1:
        if prediction == 1:
            st.success("✅ WILL COMPLETE")
        else:
            st.error("❌ NOT LIKELY TO COMPLETE")

    with col2:
        st.metric("Confidence", f"{probability[prediction]:.1%}")

    # Chart
    st.subheader("Progress Impact on Completion")

    fig, ax = plt.subplots(figsize=(8, 4))
    sample_progress = list(range(0, 101, 10))
    predictions = [model.predict_proba([[p, quiz_score]])[0][1] for p in sample_progress]

    ax.plot(sample_progress, predictions, linewidth=2)
    ax.axvline(x=progress, linestyle='--', label='Your Progress')
    ax.set_xlabel("Progress %")
    ax.set_ylabel("Completion Probability")
    ax.grid(True, alpha=0.3)
    ax.legend()
    st.pyplot(fig)

# Show few rows
with st.expander(" View Sample Data"):
    df = pd.read_csv(CSV_PATH)
    st.dataframe(df[['Progress_Percentage', 'Quiz_Score_Avg', 'Completed']].head(10))

st.markdown("---")
st.markdown("""
### Single File Instructions
- Just run: `streamlit run course_predictor.py`
- Auto trains model if not found
- Uses only 2 features
""")
st.markdown("Developed by Umair")
